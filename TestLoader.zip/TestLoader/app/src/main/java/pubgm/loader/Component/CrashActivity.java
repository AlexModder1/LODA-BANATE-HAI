package pubgm.loader.Component;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CrashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Get crash log from intent
        Intent intent = getIntent();
        String crashLog = intent.getStringExtra("crashLog");

        // Display crash log
        ScrollView scrollView = new ScrollView(this);
        TextView textView = new TextView(this);
        textView.setText(crashLog);
        scrollView.addView(textView);

        setContentView(scrollView);
    }
}
