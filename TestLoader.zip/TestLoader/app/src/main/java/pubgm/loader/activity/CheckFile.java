package pubgm.loader.activity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.net.Uri;
import android.os.Build;
import pubgm.loader.R;
import android.provider.Settings;
import android.os.Environment;
import androidx.annotation.NonNull;
import android.content.SharedPreferences;
import androidx.appcompat.app.AlertDialog;
import android.app.PendingIntent;
import io.michaelrocks.paranoid.Obfuscate;

@Obfuscate
public class CheckFile extends AppCompatActivity {

    private static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 100;
    private static final int REQUEST_CODE_MANAGE_STORAGE = 101;
    private static final int REQUEST_CODE_INSTALL_PACKAGES = 102;
    private static final int REQUEST_CODE_OVERLAY_PERMISSION = 103;
    private static final int REQUEST_CODE_LOGIN_ACTIVITY = 104;

    public static boolean mahyong = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.check);
        checkAndRequestPermissions();
    }

    private void checkAndRequestPermissions() {
        // Check if Display Over Other Apps permission is granted
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission();
        } else {
            checkInstallUnknownAppsPermission();
        }
    }

    private void checkInstallUnknownAppsPermission() {
        if (getPackageManager().canRequestPackageInstalls()) {
            // Permission already granted for installing unknown apps
            checkStoragePermissions(); // Continue checking storage permissions
        } else {
            // Request permission to install unknown apps
            requestInstallUnknownAppsPermission();
        }
    }

    private void checkStoragePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                // Permission granted for managing external storage
                startLoginActivity();
            } else {
                requestFilePermissions();
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                // Permissions granted
                startLoginActivity();
            } else {
                requestFilePermissions();
            }
        }
    }

    private void requestOverlayPermission() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, REQUEST_CODE_OVERLAY_PERMISSION);
    }

    private void requestInstallUnknownAppsPermission() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, REQUEST_CODE_INSTALL_PACKAGES);
    }

    private void requestFilePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            Uri uri = Uri.fromParts("package", getPackageName(), null);
            intent.setData(uri);
            startActivityForResult(intent, REQUEST_CODE_MANAGE_STORAGE);
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                    },
                    MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE
            );
        }
    }
    
    private boolean isFirstTime() {
    // Use SharedPreferences to store the first-time status
    SharedPreferences preferences = getSharedPreferences("AppPrefs", MODE_PRIVATE);
    boolean isFirstTime = preferences.getBoolean("isFirstTime", true);

    if (isFirstTime) {
        // Update the flag to indicate the dialog has been shown
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("isFirstTime", false);
        editor.apply();
    }

    return isFirstTime;
}


    private void startLoginActivity() {
    if (isFirstTime()) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Restart Required")
                .setMessage("Please restart the app to continue.")
                .setCancelable(false) // Prevent the dialog from being dismissed
                .setPositiveButton("OK", (dialogInterface, which) -> {
                    // Restart the app
                    Intent restartIntent = getPackageManager().getLaunchIntentForPackage(getPackageName());
                    if (restartIntent != null) {
                        restartIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                        PendingIntent pendingIntent = PendingIntent.getActivity(
                                this, 0, restartIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_CANCEL_CURRENT);
                        finishAffinity(); // Close current activity
                        System.exit(0); // Exit the app process
                        try {
                            pendingIntent.send(); // Restart the app
                        } catch (PendingIntent.CanceledException e) {
                            e.printStackTrace();
                        }
                    }
                })
                .create();

        dialog.setOnShowListener(dialogInterface -> {
            // Ensure the button's text color is visible
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(android.R.color.holo_blue_dark));
        });

        dialog.show();
    } else {
        // Directly proceed to LoginActivity
        Intent intent = new Intent(this, ModeActivity.class);
        startActivity(intent);
            mahyong = true;
        finishAffinity();
    }
}


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted for storage
                startLoginActivity();
            } else {
                Toast.makeText(this, "Storage permission is required to continue", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CODE_MANAGE_STORAGE:
                if (Environment.isExternalStorageManager()) {
                    // Permission granted for managing external storage
                    startLoginActivity();
                } else {
                    Toast.makeText(this, "Permission is required to access all files", Toast.LENGTH_SHORT).show();
                }
                break;

            case REQUEST_CODE_OVERLAY_PERMISSION:
                if (Settings.canDrawOverlays(this)) {
                    // Permission granted for overlay
                    checkInstallUnknownAppsPermission();
                } else {
                    Toast.makeText(this, "Display over other apps permission is required", Toast.LENGTH_SHORT).show();
                }
                break;

            case REQUEST_CODE_INSTALL_PACKAGES:
                if (getPackageManager().canRequestPackageInstalls()) {
                    // Permission granted for install unknown apps
                    checkStoragePermissions();
                } else {
                    Toast.makeText(this, "Install unknown apps permission is required", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }
}
