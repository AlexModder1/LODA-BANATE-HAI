package pubgm.loader.activity;

import static pubgm.loader.activity.SplashActivity.mahyong;
import static pubgm.loader.server.ApiServer.URLJSON;
import static pubgm.loader.server.ApiServer.getOwner;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.core.content.FileProvider;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import pubgm.loader.Component.UpdateChecker;
import pubgm.loader.R;
import pubgm.loader.utils.ActivityCompat;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;

import io.michaelrocks.paranoid.Obfuscate;

/**************************
 * BUILD ON Android Studio
 * TELEGRAM : OxZeroo
 * *************************/


@Obfuscate
public class ModeActivity extends ActivityCompat {

    private Context context;
    public static boolean Kooontoool = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mode);
        if (!mahyong){
            finish();
            finishActivity(1);
        }
        
        LoginActivity.setModeSelect("PUBGG");
            startActivity(new Intent(ModeActivity.this, LoginActivity.class));
            Kooontoool = true;
            
        UpdateChecker updateChecker = new UpdateChecker(this);
        updateChecker.checkForUpdate();
        LinearLayout silver = findViewById(R.id.btnfree);
        LinearLayout gold = findViewById(R.id.btnpremium);
        LinearLayout telegram = findViewById(R.id.telegramss);
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.bounce);

        telegram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animator scale = ObjectAnimator.ofPropertyValuesHolder(v,
                        PropertyValuesHolder.ofFloat(View.SCALE_X, 1, 0.5f, 1),
                        PropertyValuesHolder.ofFloat(View.SCALE_Y, 1, 0.5f, 1));
                scale.setDuration(1000);
                scale.start();
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(getOwner()));
                startActivity(intent);
            }
        });

        silver.setOnClickListener(v -> {
            Animator scale = ObjectAnimator.ofPropertyValuesHolder(v,
                    PropertyValuesHolder.ofFloat(View.SCALE_X, 1, 0.5f, 1),
                    PropertyValuesHolder.ofFloat(View.SCALE_Y, 1, 0.5f, 1));
            scale.setDuration(1000);
            scale.start();            LoginActivity.setModeSelect("PUBGS");
            startActivity(new Intent(ModeActivity.this, LoginActivity.class));
            Kooontoool = false;
        });

        gold.setOnClickListener(v -> {
            Animator scale = ObjectAnimator.ofPropertyValuesHolder(v,
                    PropertyValuesHolder.ofFloat(View.SCALE_X, 1, 0.5f, 1),
                    PropertyValuesHolder.ofFloat(View.SCALE_Y, 1, 0.5f, 1));
            scale.setDuration(1000);
            scale.start();            LoginActivity.setModeSelect("PUBGG");
            startActivity(new Intent(ModeActivity.this, LoginActivity.class));
            Kooontoool = true;
        });
    }
}
