package pubgm.loader.Component;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CrashHandler implements Thread.UncaughtExceptionHandler {

    private final Context context;
    private final Thread.UncaughtExceptionHandler defaultHandler;

    public CrashHandler(Context context) {
        this.context = context;
        this.defaultHandler = Thread.getDefaultUncaughtExceptionHandler();
    }

    @Override
    public void uncaughtException(Thread thread, Throwable throwable) {
        try {
            // Save crash log to storage
            saveCrashLog(throwable);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Start CrashActivity to display the crash
        Intent intent = new Intent(context, CrashActivity.class);
        intent.putExtra("crashLog", getStackTrace(throwable));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);

        // Terminate the app process
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(1);
    }

    private void saveCrashLog(Throwable throwable) throws IOException {
        // Determine storage directory
        File crashDir;
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            crashDir = new File(Environment.getExternalStorageDirectory(), "CrashLogs");
        } else {
            crashDir = new File(context.getFilesDir(), "CrashLogs");
        }

        // Create directory if it doesn't exist
        if (!crashDir.exists()) {
            crashDir.mkdirs();
        }

        // Create crash log file
        File crashFile = new File(crashDir, "crash_" + System.currentTimeMillis() + ".txt");
        try (FileWriter writer = new FileWriter(crashFile)) {
            writer.write(getStackTrace(throwable));
            Log.d("CrashHandler", "Crash log saved to: " + crashFile.getAbsolutePath());
        }
    }

    private String getStackTrace(Throwable throwable) {
        StringBuilder stackTrace = new StringBuilder();
        stackTrace.append("Device: ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append("\n");
        stackTrace.append("Android Version: ").append(Build.VERSION.RELEASE).append("\n");
        stackTrace.append("API Level: ").append(Build.VERSION.SDK_INT).append("\n\n");

        stackTrace.append("Exception: ").append(throwable.getClass().getName()).append("\n");
        stackTrace.append("Message: ").append(throwable.getMessage()).append("\n\n");
        stackTrace.append("Stack Trace:\n");
        for (StackTraceElement element : throwable.getStackTrace()) {
            stackTrace.append(element.toString()).append("\n");
        }

        return stackTrace.toString();
    }
}
