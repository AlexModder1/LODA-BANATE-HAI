package pubgm.loader.utils;

import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Handler;
import io.michaelrocks.paranoid.Obfuscate;
import java.util.Enumeration;  // For Enumeration class
import java.net.NetworkInterface;  // For NetworkInterface class

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.NetworkInterface;
import java.util.List;
import java.util.Locale;

@Obfuscate
public class SecurityUtils {

    private static Handler securityHandler;
    private static Runnable securityRunnable;

    public static void startPeriodicSecurityCheck(final Context context) {
        // Create and start the handler to perform the security check every second
        if (securityHandler != null) {
            securityHandler.removeCallbacks(securityRunnable); // Cancel previous task if any
        }

        securityHandler = new Handler();
        securityRunnable = new Runnable() {
            @Override
            public void run() {
                try {
                    // Perform the security check
                    checkSecurity(context);
                } catch (RuntimeException e) {
                    // Handle app crash scenario, exit the app
                    e.printStackTrace();
                    android.os.Process.killProcess(android.os.Process.myPid());
                    System.exit(1);  // Optionally crash the app
                }

                // Run the security check again after 1 second
                securityHandler.postDelayed(this, 1000);
            }
        };

        // Start the first security check immediately
        securityHandler.post(securityRunnable);
    }

    public static void stopPeriodicSecurityCheck() {
        // Stop the handler and security check
        if (securityHandler != null && securityRunnable != null) {
            securityHandler.removeCallbacks(securityRunnable);
        }
    }

    public static void checkSecurity(Context context) {
        // Check for root, emulator, HTTPS canary, and network proxy
        if (isDeviceRooted() || isRunningInEmulator() || isHttpsCanaryDetected(context) || isNetworkProxyActive(context)) {
            throw new RuntimeException("App is compromised! Crashing...");
        }
    }

    private static boolean isDeviceRooted() {
        return checkRootMethod1() || checkRootMethod2() || checkRootMethod3();
    }

    private static boolean checkRootMethod1() {
        String[] paths = {
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/su",
            "/system/bin/.ext/.su"
        };
        for (String path : paths) {
            if (new File(path).exists()) {
                return true;
            }
        }
        return false;
    }

    private static boolean checkRootMethod2() {
        Process process = null;
        try {
            process = Runtime.getRuntime().exec(new String[]{"/system/xbin/which", "su"});
            BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
            return in.readLine() != null;
        } catch (Throwable t) {
            return false;
        } finally {
            if (process != null) process.destroy();
        }
    }

    private static boolean checkRootMethod3() {
        return new File("/system/xbin/su").exists() || new File("/system/bin/su").exists();
    }

    private static boolean isRunningInEmulator() {
        return (Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.contains("vbox")   // VirtualBox
                || Build.FINGERPRINT.contains("test-keys")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MANUFACTURER.contains("Genymotion")
                || (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic"))
                || "google_sdk".equals(Build.PRODUCT)
                || "sdk".equals(Build.PRODUCT)
                || "sdk_x86".equals(Build.PRODUCT)
                || "sdk_google".equals(Build.PRODUCT)
                || "sdk_gphone64".equals(Build.PRODUCT));
    }

    private static boolean isHttpsCanaryDetected(Context context) {
        String[] canaryPackages = {
            "com.zaproxy.android",               // ZAP (Zed Attack Proxy)
            "com.charles.android",               // Charles Proxy
            "com.httpcanary",                    // HTTP Canary
            "com.mitmproxy.android",             // mitmproxy for Android
            "com.burpcollaborator",              // Burp Collaborator
        };

        for (String packageName : canaryPackages) {
            if (isAppInstalled(context, packageName) || isServiceRunning(context, packageName)) {
                return true;
            }
        }

        return false;
    }

    private static boolean isAppInstalled(Context context, String packageName) {
        try {
            return context.getPackageManager().getPackageInfo(packageName, PackageManager.GET_ACTIVITIES) != null;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private static boolean isServiceRunning(Context context, String serviceName) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> services = activityManager.getRunningServices(Integer.MAX_VALUE);

        for (ActivityManager.RunningServiceInfo service : services) {
            if (service.service.getPackageName().equals(serviceName)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isNetworkProxyActive(Context context) {
        // Check for active VPN services
        if (isVpnActive(context)) {
            return true;
        }

        // Check for known proxy interfaces
        return checkForKnownProxies();
    }

    private static boolean isVpnActive(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            NetworkCapabilities capabilities = cm.getNetworkCapabilities(cm.getActiveNetwork());
            return capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN);
        } else {
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();
            return networkInfo != null && networkInfo.getType() == ConnectivityManager.TYPE_VPN;
        }
    }

    private static boolean checkForKnownProxies() {
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                NetworkInterface networkInterface = networkInterfaces.nextElement();
                if (networkInterface.getName().toLowerCase(Locale.ROOT).contains("tun") || 
                    networkInterface.getName().toLowerCase(Locale.ROOT).contains("tap") || 
                    networkInterface.getDisplayName().toLowerCase(Locale.ROOT).contains("proxy")) {
                    return true;
                }
            }
        } catch (Exception e) {
            // Handle exceptions (e.g., log them if needed)
        }
        return false;
    }
}
