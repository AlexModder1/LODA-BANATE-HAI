package pubgm.loader.Component;

import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.exception.ZipException;

// Inside an Activity or Context
import net.lingala.zip4j.ZipFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownloadZip extends AsyncTask<String, String, String> {
    private Context context;
    private AlertDialog progressDialog;
    private ProgressBar progressBar;
    private TextView progressText;
    public static boolean checkdonwload = false;
    public native String pw();
    public DownloadZip(Context context) {
        this.context = context;

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setCancelable(false);

        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(50, 50, 50, 50);

        progressBar = new ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        layout.addView(progressBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        progressText = new TextView(context);
        progressText.setGravity(Gravity.CENTER_HORIZONTAL);
        progressText.setText("0/100");
        layout.addView(progressText);

        builder.setView(layout);
        progressDialog = builder.create();
        progressDialog.show();
    }

    @Override
    protected void onPreExecute() {
        // Delete all files before downloading
        File pathBase = new File(context.getFilesDir().getPath());
        deleteRecursive(pathBase);
    }

    @Override
    protected String doInBackground(String... strings) {
        try {
            URL url = new URL(strings[1]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            int lengthOfFile = connection.getContentLength();
            InputStream input = connection.getInputStream();
            String fileName = "assets.zip";
            File pathBase = new File(context.getFilesDir().getPath());
            if (!pathBase.exists()) {
                pathBase.mkdirs();
            }
            File pathOutput = new File(pathBase.toString() + "/" + fileName);
            OutputStream output = new FileOutputStream(pathOutput.toString());
            byte[] data = new byte[1024];
            long total = 0;
            int count;
            while ((count = input.read(data)) != -1) {
                total += count;
                publishProgress("" + (int) ((total * 100) / lengthOfFile));
                output.write(data, 0, count);
            }
            if (pathOutput.exists()) {
                new File(pathOutput.toString()).setExecutable(true, true);
            }
            output.close();
            input.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(String... progress) {
        int progressValue = Integer.parseInt(progress[0]);
        progressBar.setProgress(progressValue);
        progressText.setText(progressValue + "/100");
    }

    @Override
    protected void onPostExecute(String result) {
        File pathBase = new File(context.getFilesDir().getPath());
        File pathBase2 = new File(context.getFilesDir().getPath());

        
try {
        String password = pw();  
        ZipFile zipFile = new ZipFile(pathBase2.toString() + "/assets.zip", password.toCharArray());
        zipFile.extractAll(pathBase.toString());
    } catch (ZipException e) {
        e.printStackTrace();
    } catch (Exception e) {
        e.printStackTrace();
    }

        progressDialog.dismiss();
        checkdonwload = true;

        File newFile = new File(pathBase.toString() + "/assets.zip");
        if (newFile.exists()) {
            newFile.delete();
        }
    }

    private boolean zip4j(String path, String outpath, String password) {       
        try {
            new ZipFile(path, password.toCharArray()).extractAll(outpath);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private void ExecuteElf(String shell) {
        String s = shell;
        try {
            Runtime.getRuntime().exec(s, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void jknfthrbvgy(String path) {
        try {
            ExecuteElf("chmod 777 " + context.getFilesDir() + path);
            ExecuteElf(context.getFilesDir() + path);
            ExecuteElf("su -c chmod 777 " + context.getFilesDir() + path);
            ExecuteElf("su -c " + context.getFilesDir() + path);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.exists()) {
            if (fileOrDirectory.isDirectory()) {
                File[] files = fileOrDirectory.listFiles();
                if (files != null) {
                    for (File child : files) {
                        deleteRecursive(child);
                    }
                }
            }
            fileOrDirectory.delete();
        }
    }
}
