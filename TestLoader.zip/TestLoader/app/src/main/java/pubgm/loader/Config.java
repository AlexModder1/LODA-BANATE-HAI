package pubgm.loader;
import io.michaelrocks.paranoid.Obfuscate;

@Obfuscate
public class Config {
    public static String STATUS_BY = "online";
    public static final int USER_ID = 0;
    public static final int[] GAME_LIST_ICON = new int[]{ R.drawable.circlegl, R.drawable.circlegl, R.drawable.circlegl, R.drawable.circlegl, R.drawable.circlebgmi};
    public static final String GAME_LIST_PKG[] = {"com.tencent.ig","com.pubg.krmobile", "com.vng.pubgmobile", "com.rekoo.pubgm", "com.pubg.imobile"};
}
