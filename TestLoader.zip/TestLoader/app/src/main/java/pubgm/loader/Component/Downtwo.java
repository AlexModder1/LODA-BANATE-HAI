package pubgm.loader.Component;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import pubgm.loader.R;

import net.lingala.zip4j.ZipFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class Downtwo extends AsyncTask<String, String, String> {
    private final Context context;
    private AlertDialog progressDialog;
    private ProgressBar progressBar;
    private TextView progressText;
    public boolean success = false;

    public Downtwo(Context context) {
        this.context = context;

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setCancelable(false);

        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(50, 50, 50, 50);

        progressBar = new ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        layout.addView(progressBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        progressText = new TextView(context);
        progressText.setGravity(Gravity.CENTER_HORIZONTAL);
        progressText.setText("0/100");
        layout.addView(progressText);

        builder.setView(layout);
        progressDialog = builder.create();
        progressDialog.show();
    }

    @Override
    protected void onPreExecute() {
        File filesLoaderDir = new File(context.getFilesDir(), "loader");
        if (filesLoaderDir.exists()) {
            for (File file : filesLoaderDir.listFiles()) {
                file.delete();
            }
        }
    }

    @Override
    protected String doInBackground(String... strings) {
        try {
            URL url = new URL(strings[1]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            int lengthOfFile = connection.getContentLength();
            InputStream input = connection.getInputStream();
            String fileName = "mahyong.zip";
            File pathBase = new File(context.getFilesDir().getPath());
            if (!pathBase.exists()) {
                pathBase.mkdirs();
            }
            File pathOutput = new File(pathBase.toString() + "/" + fileName);
            OutputStream output = new FileOutputStream(pathOutput.toString());
            byte[] data = new byte[1024];
            long total = 0;
            int count;
            while ((count = input.read(data)) != -1) {
                total += count;
                publishProgress("" + (int) ((total * 100) / lengthOfFile));
                output.write(data, 0, count);
            }
            if (pathOutput.exists()) {
                new File(pathOutput.toString()).setExecutable(true, true);
            }
            output.close();
            input.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(String... progress) {
        int progressValue = Integer.parseInt(progress[0]);
        progressBar.setProgress(progressValue);
        progressText.setText(progressValue + "/100");
    }

    @Override
    protected void onPostExecute(String result) {
        File pathBase = new File(context.getFilesDir().getPath());
        File loaderDirectory = new File(pathBase, "loader");

        try {
            if (!loaderDirectory.exists()) {
                loaderDirectory.mkdirs();
            }

            progressDialog.dismiss();
            success = true;

            if (success) {
                try {
                    Class<?> deviceInfo = Class.forName("pubgm.loader.activity.DeviceInfo");
                    context.startActivity(new Intent(context.getApplicationContext(), deviceInfo));
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }

            new ZipFile(pathBase + "/mahyong.zip", "mahyong".toCharArray())
                    .extractAll(loaderDirectory.getAbsolutePath());
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (loaderDirectory.exists()) {
            setPermissions(loaderDirectory);
        }

        if (result != null) {
            Toast.makeText(context, context.getString(R.string.download_error) + result, Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(context, R.string.download_complete, Toast.LENGTH_SHORT).show();
        }

        File newFile = new File(pathBase + "/mahyong.zip");
        if (newFile.exists()) {
            newFile.delete();
        }
    }

    private void setPermissions(File directory) {
        if (directory.isDirectory()) {
            for (File file : directory.listFiles()) {
                setPermissions(file);
            }
        } else {
            directory.setReadable(true, false);
            directory.setWritable(true, false);
            directory.setExecutable(true, false);
        }
    }
}
